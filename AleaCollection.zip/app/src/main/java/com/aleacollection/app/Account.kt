package com.aleacollection.app

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.*
import kotlinx.coroutines.launch

fun errMsg(e: Exception) = when (e) {
    is FirebaseNetworkException -> "Tidak ada koneksi internet."
    is FirebaseAuthInvalidCredentialsException, is FirebaseAuthInvalidUserException -> "Email atau password salah."
    is FirebaseAuthUserCollisionException -> "Email sudah terdaftar."
    is FirebaseAuthWeakPasswordException -> "Password minimal 6 karakter."
    else -> "Terjadi kesalahan. Silakan coba lagi."
}

@Composable
fun Checkout(goLogin: () -> Unit, done: (String?, Int) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val online = Repo.ready(ctx)
    var name by remember { mutableStateOf("") }
    var wa by remember { mutableStateOf("") }
    var addr by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var applied by remember { mutableStateOf("") }
    var disc by remember { mutableIntStateOf(0) }
    if (online && Session.email == null) {
        Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Masuk dulu untuk membuat pesanan.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = goLogin) { Text("Masuk / Daftar") }
        }
    } else Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Data Pelanggan", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        val m = Modifier.fillMaxWidth()
        OutlinedTextField(name, { name = it }, m, label = { Text("Nama lengkap") }, singleLine = true)
        OutlinedTextField(wa, { wa = it }, m, label = { Text("Nomor WhatsApp") }, singleLine = true)
        OutlinedTextField(addr, { addr = it }, m, label = { Text("Alamat lengkap") })
        OutlinedTextField(city, { city = it }, m, label = { Text("Kecamatan, Kota/Kab, Provinsi, Kode Pos") })
        OutlinedTextField(note, { note = it }, m, label = { Text("Catatan pesanan (opsional)") })
        HorizontalDivider()
        Text(itemsText(Store.cart.toList()), fontSize = 14.sp)
        Row { Text("Subtotal", Modifier.weight(1f)); Text(rp(Store.total())) }
        if (online) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(code, { code = it.uppercase() }, Modifier.weight(1f), label = { Text("Kode promo") }, singleLine = true)
            OutlinedButton(onClick = {
                scope.launch {
                    try {
                        val r = Repo.checkPromo(code, Store.total())
                        if (r.error != null) { disc = 0; applied = ""; Toast.makeText(ctx, r.error, Toast.LENGTH_LONG).show() }
                        else { disc = r.discount; applied = code.trim(); Toast.makeText(ctx, "Promo dipakai.", Toast.LENGTH_SHORT).show() }
                    } catch (e: Exception) { Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show() }
                }
            }) { Text("Pakai") }
        }
        if (disc > 0) Row { Text("Diskon ($applied)", Modifier.weight(1f)); Text("-" + rp(disc)) }
        Row { Text("Total", Modifier.weight(1f), fontWeight = FontWeight.Bold); Text(rp(Store.total() - disc), fontWeight = FontWeight.Bold, color = Gold) }
        Text("Ongkir & detail pembayaran dikonfirmasi admin lewat WhatsApp.", fontSize = 12.sp)
        Button(onClick = {
            if (name.isBlank() || wa.isBlank() || addr.isBlank() || city.isBlank()) {
                Toast.makeText(ctx, "Lengkapi data pelanggan dulu.", Toast.LENGTH_SHORT).show()
            } else if (!online) {
                openWa(ctx, "Halo Admin Alea Collection, saya ingin memesan:\n${itemsText(Store.cart.toList())}\n" +
                    "Subtotal: ${rp(Store.total())}\nNama: $name\nWA: $wa\nAlamat: $addr, $city\nCatatan: $note")
                Store.cart.clear(); done(null, 0)
            } else {
                busy = true
                scope.launch {
                    try {
                        val sub = Store.total()
                        var d = 0
                        if (applied.isNotBlank()) {
                            val r = Repo.checkPromo(applied, sub)
                            if (r.error != null) {
                                disc = 0; applied = ""; busy = false
                                Toast.makeText(ctx, r.error, Toast.LENGTH_LONG).show()
                                return@launch
                            }
                            d = r.discount
                        }
                        val tot = sub - d
                        val no = Repo.createOrder(name, wa, "$addr, $city", note, Store.cart.toList(), tot, sub, applied, d)
                        Store.cart.clear()
                        done(no, tot)
                    } catch (e: Exception) {
                        Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show()
                    }
                    busy = false
                }
            }
        }, Modifier.fillMaxWidth().height(52.dp), enabled = Store.cart.isNotEmpty() && !busy) {
            Text(if (busy) "Memproses..." else "Buat Pesanan")
        }
    }
}

@Composable
fun Pesanan(onPay: (String, Long) -> Unit) {
    val ctx = LocalContext.current
    val email = Session.email
    var list by remember { mutableStateOf<List<Order>?>(null) }
    var err by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(email, tick) {
        if (email != null) {
            list = null; err = false
            try { list = Repo.myOrders() } catch (e: Exception) { err = true }
        }
    }
    val l = list
    if (!Repo.ready(ctx) || email == null) Info("Belum ada pesanan.", "Masuk lewat tab Profil untuk melihat pesananmu.")
    else if (err) Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Tidak dapat memuat pesanan. Periksa koneksi internet.")
        Button(onClick = { tick++ }) { Text("Coba Lagi") }
    }
    else if (l == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    else if (l.isEmpty()) Info("Belum ada pesanan.", "Pesananmu akan muncul di sini.")
    else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TextButton(onClick = { tick++ }) { Text("Muat ulang") } }
        items(l) { o ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("#" + o.no, fontWeight = FontWeight.Bold)
                    Text(o.status, color = Gold, fontWeight = FontWeight.SemiBold)
                    Text(o.items, fontSize = 13.sp)
                    Text("Total: " + rp(o.total.toInt()), fontWeight = FontWeight.SemiBold)
                    if (o.resi.isNotBlank()) Text("Resi: ${o.courier} ${o.resi}", fontSize = 13.sp)
                    if (o.reason.isNotBlank()) Text("Alasan penolakan: ${o.reason}", fontSize = 13.sp)
                    if (o.status == "Menunggu Pembayaran") Button(onClick = { onPay(o.no, o.total) }) { Text("Cara Bayar") }
                    OutlinedButton(onClick = { openWa(ctx, "Halo Admin Alea Collection,\nSaya ingin menanyakan pesanan #${o.no}.") }) {
                        Text("Hubungi Admin")
                    }
                }
            }
        }
    }
}

@Composable
fun Profil(openAdmin: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var reg by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val m = Modifier.fillMaxWidth()
    var isAdmin by remember { mutableStateOf(false) }
    LaunchedEffect(Session.email) {
        isAdmin = Session.email != null && try { Repo.isAdmin() } catch (e: Exception) { false }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!Repo.ready(ctx)) Text("Akun belum aktif (Firebase belum dikonfigurasi).")
        else if (Session.email != null) {
            Text("Masuk sebagai", fontSize = 12.sp)
            Text(Session.email ?: "", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            OutlinedButton(onClick = { Repo.logout(); Session.email = null }) { Text("Keluar") }
        } else {
            Text(if (reg) "Daftar Akun" else "Masuk", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (reg) OutlinedTextField(name, { name = it }, m, label = { Text("Nama lengkap") }, singleLine = true)
            OutlinedTextField(email, { email = it }, m, label = { Text("Email") }, singleLine = true)
            OutlinedTextField(pass, { pass = it }, m, label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation())
            Button(onClick = {
                if (email.isBlank() || pass.isBlank() || (reg && name.isBlank())) {
                    Toast.makeText(ctx, "Lengkapi data dulu.", Toast.LENGTH_SHORT).show()
                } else {
                    busy = true
                    scope.launch {
                        try {
                            if (reg) Repo.register(name, email, pass) else Repo.login(email, pass)
                            Session.email = Repo.user?.email
                        } catch (e: Exception) { Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show() }
                        busy = false
                    }
                }
            }, m.height(52.dp), enabled = !busy) { Text(if (reg) "Daftar" else "Masuk") }
            TextButton(onClick = { reg = !reg }) { Text(if (reg) "Sudah punya akun? Masuk" else "Belum punya akun? Daftar") }
            if (!reg) TextButton(onClick = {
                if (email.isBlank()) Toast.makeText(ctx, "Isi email dulu.", Toast.LENGTH_SHORT).show()
                else scope.launch {
                    try { Repo.reset(email); Toast.makeText(ctx, "Email reset password dikirim.", Toast.LENGTH_LONG).show() }
                    catch (e: Exception) { Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show() }
                }
            }) { Text("Lupa password?") }
        }
        if (isAdmin) Button(onClick = openAdmin, m.height(52.dp)) { Text("Dashboard Admin") }
        HorizontalDivider()
        Text("Tentang Alea Collection", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Parfum berkualitas dengan pilihan ukuran dan kualitas sesuai kebutuhanmu.")
        val st = Live.settings
        if (st.address.isNotBlank()) Text("Alamat: ${st.address}", fontSize = 13.sp)
        if (st.hours.isNotBlank()) Text("Jam operasional: ${st.hours}", fontSize = 13.sp)
        if (st.email.isNotBlank()) Text("Email: ${st.email}", fontSize = 13.sp)
        if (st.instagram.isNotBlank()) Text("Instagram: ${st.instagram}", fontSize = 13.sp)
        if (st.tiktok.isNotBlank()) Text("TikTok: ${st.tiktok}", fontSize = 13.sp)
        Button(onClick = { openWa(ctx, "Halo Admin Alea Collection, saya ingin bertanya.") }, m.height(52.dp)) { Text("Chat Admin") }
    }
}
