package com.aleacollection.app

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Calendar

val STATUSES = listOf("Menunggu Pembayaran", "Bukti Pembayaran Diterima", "Pembayaran Diverifikasi",
    "Pembayaran Ditolak", "Pesanan Diproses", "Dikirim", "Selesai")

@Composable
fun AdminScreen() {
    var tab by remember { mutableIntStateOf(0) }
    var orders by remember { mutableStateOf<List<Order>>(emptyList()) }
    var err by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        try { orders = Repo.allOrders(); err = false } catch (e: Exception) { err = true }
        try { Live.states = Repo.productStates() } catch (e: Exception) { }
    }
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
            listOf("Ringkasan", "Pesanan", "Produk", "Pembayaran", "Pengaturan", "Promo").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        if (err) Info("Gagal memuat data.", "Periksa koneksi internet, atau akunmu belum terdaftar sebagai admin.")
        else when (tab) {
            0 -> Summary(orders)
            1 -> OrdersAdmin(orders) { tick++ }
            2 -> ProductsAdmin()
            3 -> PaymentAdmin()
            4 -> SettingsAdmin()
            else -> PromoAdmin()
        }
    }
}

@Composable
fun Summary(o: List<Order>) {
    val start = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val paid = setOf("Pembayaran Diverifikasi", "Pesanan Diproses", "Dikirim", "Selesai")
    val stats = listOf(
        "Total pesanan" to "${o.size}",
        "Pesanan hari ini" to "${o.count { it.date >= start }}",
        "Pendapatan" to rp(o.filter { it.status in paid }.sumOf { it.total }.toInt()),
        "Menunggu pembayaran" to "${o.count { it.status == "Menunggu Pembayaran" || it.status == "Bukti Pembayaran Diterima" }}",
        "Diproses" to "${o.count { it.status == "Pesanan Diproses" }}",
        "Dikirim" to "${o.count { it.status == "Dikirim" }}",
        "Stok menipis (≤5)" to "${Live.states.values.count { it.active && (it.stock ?: 99) <= 5 }}"
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        stats.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (l, v) ->
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(l, fontSize = 12.sp)
                            Text(v, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gold)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun OrdersAdmin(orders: List<Order>, reload: () -> Unit) {
    var edit by remember { mutableStateOf<Order?>(null) }
    if (orders.isEmpty()) Info("Belum ada pesanan.", "")
    else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(orders, key = { it.no }) { o ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("#" + o.no, fontWeight = FontWeight.Bold)
                    Text(o.status, color = Gold, fontWeight = FontWeight.SemiBold)
                    Text("${o.name} • ${o.wa}", fontSize = 13.sp)
                    Text(o.addr, fontSize = 13.sp)
                    Text(o.items, fontSize = 13.sp)
                    Text("Total: " + rp(o.total.toInt()), fontWeight = FontWeight.SemiBold)
                    if (o.resi.isNotBlank()) Text("Resi: ${o.courier} ${o.resi}", fontSize = 13.sp)
                    OutlinedButton(onClick = { edit = o }) { Text("Ubah status / resi") }
                }
            }
        }
    }
    edit?.let { o -> EditOrder(o, onClose = { edit = null }, onSaved = { edit = null; reload() }) }
}

@Composable
fun EditOrder(o: Order, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var st by remember { mutableStateOf(o.status) }
    var cur by remember { mutableStateOf(o.courier) }
    var resi by remember { mutableStateOf(o.resi) }
    var reason by remember { mutableStateOf(o.reason) }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("#" + o.no) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                STATUSES.forEach { s -> FilterChip(st == s, { st = s }, { Text(s) }) }
                OutlinedTextField(cur, { cur = it }, label = { Text("Ekspedisi") }, singleLine = true)
                OutlinedTextField(resi, { resi = it }, label = { Text("Nomor resi") }, singleLine = true)
                if (st == "Pembayaran Ditolak") OutlinedTextField(reason, { reason = it }, label = { Text("Alasan penolakan") })
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                busy = true
                scope.launch {
                    try { Repo.updateOrder(o, st, cur, resi, reason); onSaved() }
                    catch (e: Exception) { Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show() }
                    busy = false
                }
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Batal") } }
    )
}

@Composable
fun ProductsAdmin() {
    var q by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf<Product?>(null) }
    var isNew by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Button(onClick = { edit = Product(Catalog.all.maxOf { it.id } + 1, "", Gender.Unisex, 3000); isNew = true },
            Modifier.fillMaxWidth().padding(16.dp, 8.dp)) { Text("Tambah Parfum") }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp, 0.dp), singleLine = true,
            placeholder = { Text("Cari parfum...") })
        LazyColumn(Modifier.fillMaxSize()) {
            items(Catalog.all.filter { it.name.contains(q, true) }, key = { it.id }) { p ->
                val s = Live.states[p.id] ?: PState()
                Column {
                    ListItem(
                        headlineContent = { Text(p.name) },
                        supportingContent = {
                            Text((if (s.active) "Aktif" else "Nonaktif") + " • " + p.gender.label + " • Rp" + p.tier +
                                " • " + (s.stock?.let { "Stok $it" } ?: "Stok tidak dibatasi"))
                        },
                        modifier = Modifier.clickable { edit = p; isNew = false }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
    edit?.let { p -> EditProduct(p, isNew) { edit = null } }
}

@Composable
fun EditProduct(p: Product, isNew: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val old = Live.states[p.id]
    var name by remember { mutableStateOf(p.name) }
    var gender by remember { mutableStateOf(p.gender) }
    var tier by remember { mutableIntStateOf(p.tier) }
    var active by remember { mutableStateOf(old?.active ?: true) }
    var stock by remember { mutableStateOf(old?.stock?.toString() ?: "") }
    var busy by remember { mutableStateOf(false) }
    val custom = isNew || old?.custom == true
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (isNew) "Parfum Baru" else "Ubah Parfum") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nama parfum") }, singleLine = true)
                Text("Kategori")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Gender.values().forEach { g -> FilterChip(gender == g, { gender = g }, { Text(g.label) }) }
                }
                Text("Kelompok harga (per ML)")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(2500, 3000, 4000).forEach { t -> FilterChip(tier == t, { tier = t }, { Text(rp(t)) }) }
                }
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Tampilkan di toko", Modifier.weight(1f))
                    Switch(active, { active = it })
                }
                OutlinedTextField(stock, { stock = it.filter { c -> c.isDigit() } }, singleLine = true,
                    label = { Text("Stok (kosongkan = tidak dibatasi)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                if (name.isBlank()) Toast.makeText(ctx, "Isi nama parfum dulu.", Toast.LENGTH_SHORT).show()
                else {
                    busy = true
                    val ps = PState(active, stock.toIntOrNull(), name.trim(), gender.name, tier, custom)
                    scope.launch {
                        try {
                            Repo.saveProduct(p.id, ps)
                            Live.states = Live.states + (p.id to ps)
                            onClose()
                        } catch (e: Exception) { Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show() }
                        busy = false
                    }
                }
            }) { Text("Simpan") }
        },
        dismissButton = {
            Row {
                if (custom && !isNew) TextButton(onClick = {
                    scope.launch {
                        try { Repo.deleteProduct(p.id); Live.states = Live.states - p.id; onClose() }
                        catch (e: Exception) { Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show() }
                    }
                }) { Text("Hapus") }
                TextButton(onClick = onClose) { Text("Batal") }
            }
        }
    )
}
