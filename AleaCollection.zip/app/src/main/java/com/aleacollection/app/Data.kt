package com.aleacollection.app

import androidx.compose.runtime.mutableStateListOf
import java.text.NumberFormat
import java.util.Locale

object Config {
    // Ganti dengan nomor WhatsApp toko (format 62..., tanpa + dan spasi)
    const val WA = "6280000000000"
}

enum class Gender(val label: String) { Pria("Pria"), Wanita("Wanita"), Unisex("Unisex") }
enum class Quality(val label: String) { Standard("Standard"), Gold("Gold"), Platinum("Platinum") }
data class Product(val id: Int, val name: String, val gender: Gender, val tier: Int)
data class CartItem(val pid: Int, val q: Quality, val ml: Int, val qty: Int)

fun rp(n: Int): String = "Rp" + NumberFormat.getInstance(Locale("id", "ID")).format(n)

/** Satu-satunya tempat harga. Angka dalam ribuan rupiah. */
object Prices {
    private fun t(vararg p: Pair<Int, Int>) = p.associate { it.first to it.second * 1000 }
    private val tables: Map<Int, Map<Quality, Map<Int, Int>>> = mapOf(
        2500 to mapOf(
            Quality.Standard to t(15 to 25, 20 to 35, 30 to 45, 50 to 65, 100 to 125),
            Quality.Gold to t(8 to 15, 10 to 20, 15 to 30, 20 to 40, 30 to 50, 50 to 90, 100 to 175),
            Quality.Platinum to t(8 to 20, 10 to 25, 15 to 35, 20 to 45, 30 to 60, 50 to 100, 100 to 200)
        ),
        3000 to mapOf(
            Quality.Standard to t(15 to 30, 20 to 35, 30 to 50, 50 to 80, 100 to 150),
            Quality.Gold to t(8 to 20, 10 to 25, 15 to 35, 20 to 45, 30 to 65, 50 to 105, 100 to 210),
            Quality.Platinum to t(8 to 25, 10 to 30, 15 to 40, 20 to 55, 30 to 70, 50 to 120, 100 to 240)
        ),
        4000 to mapOf(
            Quality.Standard to t(15 to 35, 20 to 45, 30 to 65, 50 to 100, 100 to 200),
            Quality.Gold to t(8 to 25, 10 to 35, 15 to 45, 20 to 60, 30 to 85, 50 to 140, 100 to 280),
            Quality.Platinum to t(8 to 35, 10 to 40, 15 to 50, 20 to 75, 30 to 100, 50 to 160, 100 to 320)
        )
    )
    fun sizes(p: Product, q: Quality) = tables.getValue(p.tier).getValue(q).keys.sorted()
    fun price(p: Product, q: Quality, ml: Int) = tables.getValue(p.tier).getValue(q).getValue(ml)
    fun from(p: Product) = tables.getValue(p.tier).values.minOf { it.values.min() }
}

object Catalog {
    // Kelompok harga sesuai daftar toko: no.1-53 = 2.500, 54-62 = 3.000, 63-70 = 4.000. Kategori pria/wanita/unisex masih perkiraan.
    private val men = setOf(
        "Dunhill Blue", "Maher Zein", "Dior Sauvage", "Polo Sport", "Dunhill London", "Pac. Invictus",
        "Creed Aventus", "Aigner Blue", "Jaguar Blue", "Aigner Black", "Lacoste Essential S", "Aqua Man",
        "Dunhill Red", "Jaguar Vision", "Bulgari Extrem", "HB Orange Man", "212 Men", "Mercedes Benz",
        "Raffi Ahmad", "Sotb", "Aigner Debut"
    )
    private val uni = setOf("Baccarat Rouge", "Kasturi Kiyang", "Kasturi Putih", "Ds White Musk", "Cuddle Baby", "May Way")
    private val names = listOf(
        "Bubble Gum", "Pink Chiffon", "Coach By Coach", "Avril Forbidden R", "Maher Zein", "Romantic Wish",
        "Selena Gomez", "Vs Scandalous", "Dunhill Blue", "Vanilla Bodies", "Olla Ramlan", "Britney Fantasy",
        "Dior Sauvage", "Angel Heart", "Cuddle Baby", "Dune", "Polo Sport", "Issey Miyake", "Jlo Still",
        "Dunhill London", "Diamor Women", "D&G Light Blue Women", "Taylor Swift", "Aqua Kiss", "Annasui Dream",
        "Kasturi Kiyang", "Raffi Ahmad", "Gucci Gardenia", "Pac. Invictus", "Vs Bombshell", "Creed Aventus",
        "CK Eternity Woman", "Lovely", "Vs So Sexy", "Lanvin Modern Princess", "Jlo Platinum", "Ysl Black Opium",
        "Aigner Blue", "Benetton Pink", "Jaguar Blue", "Aigner Black", "Escada Cherry In A", "Guess Pink",
        "Lacoste Essential S", "Aqua Man", "Greenlea Laverne", "Guess Girl Summer", "LV Ombre Naumade",
        "Baccarat Rouge", "May Way", "Dunhill Red", "Paris Hilton Women", "Annasui Fancy", "Kasturi Putih",
        "Incanto Shine LV", "Jaguar Vision", "LV Imagination", "Bulgari Aqua", "Mercedes Benz", "Sotb",
        "Jo Malone English P", "Sasha Scarlett", "Bulgari Extrem", "Coco Chanel", "HB Orange Man",
        "Lancome Lavie S B", "212 Men", "Aigner Debut", "Ds White Musk", "Nina Ricci L'Extase"
    )
    private val base: List<Product> = names.mapIndexed { i, n ->
        Product(i + 1, n, when (n) { in men -> Gender.Pria; in uni -> Gender.Unisex; else -> Gender.Wanita },
            when (i + 1) { in 54..62 -> 3000; in 63..70 -> 4000; else -> 2500 })
    }
    private fun genderOf(g: String?) = Gender.values().firstOrNull { it.name == g }

    /** Daftar dasar + perubahan dari admin (nama/kategori/kelompok harga) + parfum tambahan. */
    val all: List<Product>
        get() {
            val st = Live.states
            val b = base.map { p ->
                val s = st[p.id]
                if (s == null) p else p.copy(name = s.name ?: p.name, gender = genderOf(s.gender) ?: p.gender, tier = s.tier ?: p.tier)
            }
            val extra = st.filter { it.value.custom && it.key > base.size }.map { (id, s) ->
                Product(id, s.name ?: "Parfum", genderOf(s.gender) ?: Gender.Unisex, s.tier ?: 3000)
            }.sortedBy { it.id }
            return b + extra
        }

    fun byId(id: Int) = all.firstOrNull { it.id == id } ?: Product(id, "Parfum #$id", Gender.Unisex, 3000)
    fun shown() = all.filter { Live.active(it.id) }
}

object Store {
    val cart = mutableStateListOf<CartItem>()
    val favs = mutableStateListOf<Int>()
    fun add(pid: Int, q: Quality, ml: Int, n: Int) {
        val i = cart.indexOfFirst { it.pid == pid && it.q == q && it.ml == ml }
        if (i >= 0) cart[i] = cart[i].copy(qty = cart[i].qty + n) else cart.add(CartItem(pid, q, ml, n))
    }
    fun change(it: CartItem, d: Int) {
        val i = cart.indexOf(it)
        if (i < 0) return
        val nq = it.qty + d
        if (nq <= 0) cart.removeAt(i) else cart[i] = it.copy(qty = nq)
    }
    fun unit(it: CartItem) = Prices.price(Catalog.byId(it.pid), it.q, it.ml)
    fun total() = cart.sumOf { unit(it) * it.qty }
    fun toggleFav(id: Int) { if (!favs.remove(id)) favs.add(id) }
}
