package com.aleacollection.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import java.io.ByteArrayOutputStream

/** Foto dikecilkan (maks 600px, JPEG) lalu disimpan sebagai teks di Firestore. */
fun photoFromUri(ctx: Context, uri: Uri): String? = try {
    val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    if (src == null) null else {
        val sc = minOf(1f, 600f / maxOf(src.width, src.height))
        val bmp = if (sc < 1f) Bitmap.createScaledBitmap(src, (src.width * sc).toInt(), (src.height * sc).toInt(), true) else src
        var q = 85
        var out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, q, out)
        while (out.size() > 200_000 && q > 40) {
            q -= 15
            out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, q, out)
        }
        if (out.size() > 200_000) null else Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
} catch (e: Exception) { null }

/** Foto produk dari database; kalau belum ada, tampil ilustrasi botol sesuai kategori. */
@Composable
fun ProductImage(p: Product, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    LaunchedEffect(p.id) {
        if (Live.photos[p.id] == null && Repo.ready(ctx)) {
            try { Live.photos[p.id] = Repo.getPhoto(p.id) ?: "" } catch (e: Exception) { }
        }
    }
    val b64 = Live.photos[p.id].orEmpty()
    val bmp = remember(b64) { if (b64.isBlank()) null else decodeQr(b64) }
    Box(modifier, contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, p.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else BottleArt(p.gender)
    }
}

@Composable
fun BottleArt(g: Gender, modifier: Modifier = Modifier) {
    val (bg, body) = when (g) {
        Gender.Pria -> Color(0xFFDDE4EB) to Color(0xFF3E5063)
        Gender.Wanita -> Color(0xFFF4E1E1) to Color(0xFFC98B93)
        Gender.Unisex -> Color(0xFFEDE5D3) to Color(0xFF9A8556)
    }
    Canvas(modifier.fillMaxSize().background(bg)) {
        val bw = minOf(size.width * 0.34f, size.height * 0.42f)
        val bh = bw * 1.25f
        val cx = size.width / 2
        val y0 = (size.height - (bw * 0.4f + bh)) / 2
        val gold = Gold
        drawRoundRect(gold, Offset(cx - bw * 0.2f, y0), Size(bw * 0.4f, bw * 0.22f), CornerRadius(bw * 0.04f))
        drawRect(gold.copy(alpha = 0.7f), Offset(cx - bw * 0.12f, y0 + bw * 0.22f), Size(bw * 0.24f, bw * 0.18f))
        val bt = y0 + bw * 0.4f
        drawRoundRect(body, Offset(cx - bw / 2, bt), Size(bw, bh), CornerRadius(bw * 0.18f))
        drawRoundRect(gold, Offset(cx - bw / 2, bt), Size(bw, bh), CornerRadius(bw * 0.18f), style = Stroke(bw * 0.03f))
        drawRoundRect(Color.White.copy(alpha = 0.85f), Offset(cx - bw * 0.28f, bt + bh * 0.35f), Size(bw * 0.56f, bh * 0.28f), CornerRadius(bw * 0.03f))
    }
}
