package com.aleacollection.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

val BANKS = listOf("BRI", "BNI", "Mandiri", "BSI", "BCA", "CIMB Niaga", "Permata", "BTN", "Danamon",
    "SeaBank", "Jago", "Dana", "OVO", "GoPay", "ShopeePay")

fun decodeQr(b64: String): ImageBitmap? = try {
    val b = Base64.decode(b64, Base64.DEFAULT)
    BitmapFactory.decodeByteArray(b, 0, b.size)?.asImageBitmap()
} catch (e: Exception) { null }

/** Gambar QRIS dikecilkan lalu disimpan sebagai teks di Firestore (tanpa Firebase Storage). */
fun qrisFromUri(ctx: Context, uri: Uri): String? = try {
    val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    if (src == null) null else {
        val sc = minOf(1f, 800f / maxOf(src.width, src.height))
        val bmp = if (sc < 1f) Bitmap.createScaledBitmap(src, (src.width * sc).toInt(), (src.height * sc).toInt(), true) else src
        var out = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (out.size() > 600_000) out = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        if (out.size() > 600_000) null else Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
} catch (e: Exception) { null }

@Composable
fun PayScreen(no: String, total: Long) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var list by remember { mutableStateOf<List<PayMethod>?>(null) }
    var err by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { try { list = Repo.payMethods().filter { it.active } } catch (e: Exception) { err = true } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Pesanan #$no", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Total pembayaran", fontSize = 12.sp)
        Text(rp(total.toInt()), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Gold)
        Text("Pilih salah satu metode pembayaran:")
        val l = list
        if (err) Text("Tidak dapat memuat metode pembayaran. Periksa koneksi internet.")
        else if (l == null) CircularProgressIndicator()
        else if (l.isEmpty()) Text("Metode pembayaran belum tersedia. Silakan hubungi admin.")
        else l.forEach { m ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (m.type == "qris") {
                        Text("QRIS", fontWeight = FontWeight.Bold)
                        val bmp = remember(m.qris) { decodeQr(m.qris) }
                        if (bmp != null) Image(bmp, "QRIS", Modifier.fillMaxWidth().aspectRatio(1f))
                        else Text("Gambar QRIS belum tersedia.")
                        if (m.holder.isNotBlank()) Text(m.holder)
                    } else {
                        Text(m.name, fontWeight = FontWeight.Bold)
                        Text(m.number, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Text("a.n. " + m.holder, fontSize = 13.sp)
                        OutlinedButton(onClick = {
                            clip.setText(AnnotatedString(m.number))
                            Toast.makeText(ctx, "Nomor rekening disalin", Toast.LENGTH_SHORT).show()
                        }) { Text("Salin Nomor Rekening") }
                    }
                }
            }
        }
        Button(onClick = {
            openWa(ctx, "Halo Admin Alea Collection,\nSaya sudah melakukan pembayaran untuk pesanan #$no sebesar ${rp(total.toInt())}.\n(Bukti pembayaran saya lampirkan di chat ini)")
        }, Modifier.fillMaxWidth().height(52.dp)) { Text("Kirim Bukti Pembayaran") }
        Text("Setelah membayar, kirim screenshot bukti lewat WhatsApp. Admin akan memverifikasi dan status pesananmu berubah.", fontSize = 12.sp)
    }
}

@Composable
fun PaymentAdmin() {
    var list by remember { mutableStateOf<List<PayMethod>>(emptyList()) }
    var err by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf<PayMethod?>(null) }
    LaunchedEffect(tick) { try { list = Repo.payMethods(); err = false } catch (e: Exception) { err = true } }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { edit = PayMethod() }, Modifier.fillMaxWidth()) { Text("Tambah Metode Pembayaran") }
        if (err) Text("Gagal memuat data.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { m ->
                Card(Modifier.fillMaxWidth().clickable { edit = m }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(if (m.type == "qris") "QRIS" else m.name, fontWeight = FontWeight.Bold)
                        Text(if (m.type == "qris") (if (m.qris.isBlank()) "Gambar belum diunggah" else "Gambar terpasang")
                            else "${m.number} • a.n. ${m.holder}", fontSize = 13.sp)
                        Text(if (m.active) "Aktif" else "Nonaktif", fontSize = 12.sp, color = Gold)
                    }
                }
            }
        }
    }
    edit?.let { m -> EditPay(m, onClose = { edit = null }, onSaved = { edit = null; tick++ }) }
}

@Composable
fun EditPay(m: PayMethod, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var type by remember { mutableStateOf(m.type) }
    var name by remember { mutableStateOf(m.name) }
    var number by remember { mutableStateOf(m.number) }
    var holder by remember { mutableStateOf(m.holder) }
    var qris by remember { mutableStateOf(m.qris) }
    var active by remember { mutableStateOf(m.active) }
    var busy by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val r = qrisFromUri(ctx, uri)
            if (r == null) Toast.makeText(ctx, "Gambar tidak bisa dipakai atau terlalu besar.", Toast.LENGTH_LONG).show() else qris = r
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (m.id.isBlank()) "Metode Baru" else "Ubah Metode") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == "bank", { type = "bank" }, { Text("Transfer Bank") })
                    FilterChip(type == "qris", { type = "qris" }, { Text("QRIS") })
                }
                if (type == "bank") {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BANKS.forEach { b -> FilterChip(name == b, { name = b }, { Text(b) }) }
                    }
                    OutlinedTextField(name, { name = it }, label = { Text("Nama bank / e-wallet") }, singleLine = true)
                    OutlinedTextField(number, { number = it }, label = { Text("Nomor rekening") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(holder, { holder = it }, label = { Text("Nama pemilik rekening") }, singleLine = true)
                } else {
                    OutlinedButton(onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                        Text(if (qris.isBlank()) "Pilih gambar QRIS" else "Ganti gambar QRIS")
                    }
                    val bmp = remember(qris) { if (qris.isBlank()) null else decodeQr(qris) }
                    if (bmp != null) Image(bmp, "QRIS", Modifier.size(160.dp))
                    OutlinedTextField(holder, { holder = it }, label = { Text("Nama merchant (opsional)") }, singleLine = true)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Aktif", Modifier.weight(1f))
                    Switch(active, { active = it })
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val bad = if (type == "bank") (name.isBlank() || number.isBlank() || holder.isBlank()) else qris.isBlank()
                if (bad) Toast.makeText(ctx, "Lengkapi data dulu.", Toast.LENGTH_SHORT).show()
                else {
                    busy = true
                    scope.launch {
                        try {
                            Repo.savePay(PayMethod(m.id, type, if (type == "qris") "QRIS" else name,
                                if (type == "qris") "" else number, holder, if (type == "qris") qris else "", active))
                            onSaved()
                        } catch (e: Exception) { Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show() }
                        busy = false
                    }
                }
            }) { Text("Simpan") }
        },
        dismissButton = {
            Row {
                if (m.id.isNotBlank()) TextButton(onClick = {
                    scope.launch {
                        try { Repo.deletePay(m.id); onSaved() }
                        catch (e: Exception) { Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show() }
                    }
                }) { Text("Hapus") }
                TextButton(onClick = onClose) { Text("Batal") }
            }
        }
    )
}
