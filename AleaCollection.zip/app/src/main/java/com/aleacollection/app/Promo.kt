package com.aleacollection.app

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtDate(ms: Long) = if (ms <= 0) "" else SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))

/** Kosong = tidak dibatasi (0). Format salah = null. */
fun parseDate(s: String, endOfDay: Boolean): Long? {
    if (s.isBlank()) return 0L
    return try {
        val t = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(s.trim())!!.time
        if (endOfDay) t + 86_400_000L - 1 else t
    } catch (e: Exception) { null }
}

@Composable
fun PromoAdmin() {
    var list by remember { mutableStateOf<List<Promo>>(emptyList()) }
    var err by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf<Promo?>(null) }
    LaunchedEffect(tick) { try { list = Repo.promos(); err = false } catch (e: Exception) { err = true } }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { edit = Promo() }, Modifier.fillMaxWidth()) { Text("Tambah Kode Promo") }
        if (err) Text("Gagal memuat data.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.code }) { p ->
                Card(Modifier.fillMaxWidth().clickable { edit = p }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(p.code, fontWeight = FontWeight.Bold)
                        Text((if (p.type == "percent") "${p.value}%" else rp(p.value)) +
                            (if (p.minBuy > 0) " • min ${rp(p.minBuy)}" else ""), fontSize = 13.sp)
                        val range = fmtDate(p.startAt) + " s/d " + fmtDate(p.endAt)
                        if (p.startAt > 0 || p.endAt > 0) Text(range, fontSize = 12.sp)
                        Text(if (p.active) "Aktif" else "Nonaktif", fontSize = 12.sp, color = Gold)
                    }
                }
            }
        }
    }
    edit?.let { p -> EditPromo(p, onClose = { edit = null }, onSaved = { edit = null; tick++ }) }
}

@Composable
fun EditPromo(p: Promo, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isNew = p.code.isBlank()
    var code by remember { mutableStateOf(p.code) }
    var type by remember { mutableStateOf(p.type) }
    var value by remember { mutableStateOf(if (p.value > 0) p.value.toString() else "") }
    var minBuy by remember { mutableStateOf(if (p.minBuy > 0) p.minBuy.toString() else "") }
    var maxDisc by remember { mutableStateOf(if (p.maxDisc > 0) p.maxDisc.toString() else "") }
    var start by remember { mutableStateOf(fmtDate(p.startAt)) }
    var end by remember { mutableStateOf(fmtDate(p.endAt)) }
    var active by remember { mutableStateOf(p.active) }
    var busy by remember { mutableStateOf(false) }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (isNew) "Promo Baru" else "Ubah Promo") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(code, { code = it.uppercase().filter { c -> c.isLetterOrDigit() } }, enabled = isNew,
                    label = { Text("Kode (contoh: ALEA10)") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == "percent", { type = "percent" }, { Text("Persen") })
                    FilterChip(type == "nominal", { type = "nominal" }, { Text("Nominal") })
                }
                OutlinedTextField(value, { value = it.filter { c -> c.isDigit() } }, keyboardOptions = num, singleLine = true,
                    label = { Text(if (type == "percent") "Diskon (%)" else "Diskon (Rp)") })
                OutlinedTextField(minBuy, { minBuy = it.filter { c -> c.isDigit() } }, keyboardOptions = num, singleLine = true,
                    label = { Text("Minimum belanja (Rp)") })
                if (type == "percent") OutlinedTextField(maxDisc, { maxDisc = it.filter { c -> c.isDigit() } }, keyboardOptions = num,
                    singleLine = true, label = { Text("Maksimum diskon (Rp, kosong = tanpa batas)") })
                OutlinedTextField(start, { start = it }, singleLine = true, label = { Text("Mulai (yyyy-MM-dd, boleh kosong)") })
                OutlinedTextField(end, { end = it }, singleLine = true, label = { Text("Berakhir (yyyy-MM-dd, boleh kosong)") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Aktif", Modifier.weight(1f))
                    Switch(active, { active = it })
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val v = value.toIntOrNull() ?: 0
                val s = parseDate(start, false)
                val e = parseDate(end, true)
                val msg = when {
                    code.isBlank() || v <= 0 -> "Isi kode dan nilai diskon."
                    type == "percent" && v > 100 -> "Persen maksimal 100."
                    s == null || e == null -> "Format tanggal harus yyyy-MM-dd."
                    else -> null
                }
                if (msg != null) Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                else {
                    busy = true
                    scope.launch {
                        try {
                            Repo.savePromo(Promo(code, type, v, minBuy.toIntOrNull() ?: 0,
                                if (type == "percent") maxDisc.toIntOrNull() ?: 0 else 0, s ?: 0L, e ?: 0L, active))
                            onSaved()
                        } catch (ex: Exception) { Toast.makeText(ctx, errMsg(ex), Toast.LENGTH_LONG).show() }
                        busy = false
                    }
                }
            }) { Text("Simpan") }
        },
        dismissButton = {
            Row {
                if (!isNew) TextButton(onClick = {
                    scope.launch {
                        try { Repo.deletePromo(p.code); onSaved() }
                        catch (ex: Exception) { Toast.makeText(ctx, errMsg(ex), Toast.LENGTH_LONG).show() }
                    }
                }) { Text("Hapus") }
                TextButton(onClick = onClose) { Text("Batal") }
            }
        }
    )
}
