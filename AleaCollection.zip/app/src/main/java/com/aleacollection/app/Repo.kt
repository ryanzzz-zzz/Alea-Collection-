package com.aleacollection.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Session { var email by mutableStateOf<String?>(null) }

data class Order(val no: String, val status: String, val total: Long, val items: String,
                 val courier: String, val resi: String, val date: Long,
                 val name: String = "", val wa: String = "", val addr: String = "", val reason: String = "")

data class PayMethod(val id: String = "", val type: String = "bank", val name: String = "",
                     val number: String = "", val holder: String = "", val qris: String = "", val active: Boolean = true)

data class StoreSettings(val name: String = "Alea Collection", val wa: String = "", val address: String = "",
                         val email: String = "", val hours: String = "", val instagram: String = "", val tiktok: String = "")

/** 0812... -> 62812..., buang spasi/tanda */
fun waDigits(s: String): String {
    val d = s.filter { it.isDigit() }
    return if (d.startsWith("0")) "62" + d.drop(1) else d
}

data class Promo(val code: String = "", val type: String = "percent", val value: Int = 0, val minBuy: Int = 0,
                 val maxDisc: Int = 0, val startAt: Long = 0, val endAt: Long = 0, val active: Boolean = true)

data class PromoResult(val discount: Int = 0, val error: String? = null)

data class PState(val active: Boolean = true, val stock: Int? = null, val name: String? = null,
                  val gender: String? = null, val tier: Int? = null, val custom: Boolean = false)

object Live {
    val photos = mutableStateMapOf<Int, String>()
    var settings by mutableStateOf(StoreSettings())
    var states by mutableStateOf<Map<Int, PState>>(emptyMap())
    fun active(id: Int) = states[id]?.active ?: true
    fun stock(id: Int) = states[id]?.stock
}

fun itemsText(items: List<CartItem>) = items.joinToString("\n") {
    "- ${Catalog.byId(it.pid).name} • ${it.q.label} ${it.ml} ML x${it.qty} = ${rp(Store.unit(it) * it.qty)}"
}

object Repo {
    fun ready(c: Context) = FirebaseApp.getApps(c).isNotEmpty()
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    val user: FirebaseUser? get() = auth.currentUser

    suspend fun login(e: String, p: String) { auth.signInWithEmailAndPassword(e.trim(), p).await() }
    suspend fun register(n: String, e: String, p: String) {
        val u = auth.createUserWithEmailAndPassword(e.trim(), p).await().user!!
        db.collection("users").document(u.uid)
            .set(mapOf("name" to n.trim(), "email" to e.trim(), "role" to "customer")).await()
    }
    suspend fun reset(e: String) { auth.sendPasswordResetEmail(e.trim()).await() }
    fun logout() = auth.signOut()

    /** Nomor order unik per hari lewat transaksi counter: ALEA-yyyyMMdd-0001 */
    suspend fun createOrder(name: String, wa: String, addr: String, note: String,
                            items: List<CartItem>, total: Int,
                            subtotal: Int = total, promo: String = "", discount: Int = 0): String {
        val uid = auth.currentUser!!.uid
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val cref = db.collection("counters").document(day)
        var no = ""
        db.runTransaction { t ->
            val n = (t.get(cref).getLong("n") ?: 0L) + 1
            t.set(cref, mapOf("n" to n))
            no = "ALEA-$day-" + n.toString().padStart(4, '0')
            t.set(db.collection("orders").document(no), mapOf(
                "number" to no, "uid" to uid, "customerName" to name, "whatsapp" to wa,
                "address" to addr, "note" to note, "total" to total.toLong(),
                "subtotal" to subtotal.toLong(), "promoCode" to promo, "discount" to discount.toLong(),
                "status" to "Menunggu Pembayaran", "courier" to "", "resi" to "",
                "itemsText" to itemsText(items),
                "items" to items.map {
                    mapOf("productId" to it.pid, "name" to Catalog.byId(it.pid).name, "quality" to it.q.label,
                        "ml" to it.ml, "qty" to it.qty, "unitPrice" to Store.unit(it))
                },
                "createdAt" to FieldValue.serverTimestamp()
            ))
            null
        }.await()
        return no
    }

    private fun orderOf(d: DocumentSnapshot) = Order(
        d.getString("number") ?: d.id, d.getString("status") ?: "", d.getLong("total") ?: 0L,
        d.getString("itemsText") ?: "", d.getString("courier") ?: "", d.getString("resi") ?: "",
        d.getTimestamp("createdAt")?.toDate()?.time ?: 0L,
        d.getString("customerName") ?: "", d.getString("whatsapp") ?: "",
        d.getString("address") ?: "", d.getString("rejectReason") ?: ""
    )

    suspend fun myOrders(): List<Order> {
        val uid = auth.currentUser?.uid ?: return emptyList()
        return db.collection("orders").whereEqualTo("uid", uid).get().await().documents
            .map { orderOf(it) }.sortedByDescending { it.date }
    }

    suspend fun isAdmin(): Boolean {
        val u = auth.currentUser ?: return false
        return db.collection("admins").document(u.uid).get().await().exists()
    }

    suspend fun allOrders(): List<Order> =
        db.collection("orders").get().await().documents.map { orderOf(it) }.sortedByDescending { it.date }

    suspend fun productStates(): Map<Int, PState> =
        db.collection("product_state").get().await().documents.mapNotNull { d ->
            d.id.toIntOrNull()?.let { it to PState(d.getBoolean("active") ?: true, d.getLong("stock")?.toInt(), d.getString("name"),
                d.getString("gender"), d.getLong("tier")?.toInt(), d.getBoolean("custom") ?: false) }
        }.toMap()

    suspend fun saveProduct(id: Int, s: PState) {
        db.collection("product_state").document(id.toString()).set(mapOf("active" to s.active, "stock" to s.stock,
            "name" to s.name, "gender" to s.gender, "tier" to s.tier, "custom" to s.custom)).await()
    }

    suspend fun deleteProduct(id: Int) { db.collection("product_state").document(id.toString()).delete().await() }

    /** Saat status menjadi "Pembayaran Diverifikasi", stok berkurang (tidak pernah minus). */
    suspend fun updateOrder(o: Order, status: String, courier: String, resi: String, reason: String) {
        val ref = db.collection("orders").document(o.no)
        val upd = mapOf("status" to status, "courier" to courier.trim(), "resi" to resi.trim(),
            "rejectReason" to (if (status == "Pembayaran Ditolak") reason.trim() else ""))
        if (status == "Pembayaran Diverifikasi" && o.status != "Pembayaran Diverifikasi") {
            db.runTransaction { t ->
                @Suppress("UNCHECKED_CAST")
                val lines = (t.get(ref).get("items") as? List<*>)?.mapNotNull { it as? Map<String, Any> } ?: emptyList()
                val need = lines.groupBy { (it["productId"] as Number).toInt() }
                    .mapValues { e -> e.value.sumOf { (it["qty"] as Number).toInt() } }
                val refs = need.keys.associateWith { db.collection("product_state").document(it.toString()) }
                val snaps = refs.mapValues { t.get(it.value) }
                t.update(ref, upd)
                need.forEach { (id, q) ->
                    val sn = snaps.getValue(id)
                    val st = sn.getLong("stock")
                    if (sn.exists() && st != null) t.update(refs.getValue(id), "stock", maxOf(0L, st - q))
                }
                null
            }.await()
        } else ref.update(upd).await()
    }

    suspend fun payMethods(): List<PayMethod> =
        db.collection("payment_methods").get().await().documents.map { d ->
            PayMethod(d.id, d.getString("type") ?: "bank", d.getString("name") ?: "", d.getString("number") ?: "",
                d.getString("holder") ?: "", d.getString("qris") ?: "", d.getBoolean("active") ?: true)
        }.sortedWith(compareBy({ it.type != "qris" }, { it.name }))

    suspend fun savePay(m: PayMethod) {
        val col = db.collection("payment_methods")
        val ref = if (m.id.isBlank()) col.document() else col.document(m.id)
        ref.set(mapOf("type" to m.type, "name" to m.name.trim(), "number" to m.number.trim(),
            "holder" to m.holder.trim(), "qris" to m.qris, "active" to m.active)).await()
    }

    suspend fun deletePay(id: String) { db.collection("payment_methods").document(id).delete().await() }

    suspend fun getSettings(): StoreSettings {
        val d = db.collection("settings").document("store").get().await()
        return StoreSettings(d.getString("name") ?: "Alea Collection", d.getString("wa") ?: "",
            d.getString("address") ?: "", d.getString("email") ?: "", d.getString("hours") ?: "",
            d.getString("instagram") ?: "", d.getString("tiktok") ?: "")
    }

    suspend fun saveSettings(s: StoreSettings) {
        db.collection("settings").document("store").set(mapOf("name" to s.name.trim(), "wa" to waDigits(s.wa),
            "address" to s.address.trim(), "email" to s.email.trim(), "hours" to s.hours.trim(),
            "instagram" to s.instagram.trim(), "tiktok" to s.tiktok.trim())).await()
    }

    private fun promoOf(d: DocumentSnapshot) = Promo(d.id, d.getString("type") ?: "percent",
        d.getLong("value")?.toInt() ?: 0, d.getLong("minBuy")?.toInt() ?: 0, d.getLong("maxDisc")?.toInt() ?: 0,
        d.getLong("startAt") ?: 0L, d.getLong("endAt") ?: 0L, d.getBoolean("active") ?: true)

    suspend fun checkPromo(code: String, subtotal: Int): PromoResult {
        val c = code.trim().uppercase()
        if (c.isBlank()) return PromoResult(error = "Masukkan kode promo.")
        val d = db.collection("promos").document(c).get().await()
        if (!d.exists()) return PromoResult(error = "Kode promo tidak ditemukan.")
        val p = promoOf(d)
        val now = System.currentTimeMillis()
        if (!p.active || (p.startAt > 0 && now < p.startAt) || (p.endAt > 0 && now > p.endAt))
            return PromoResult(error = "Kode promo tidak berlaku.")
        if (subtotal < p.minBuy) return PromoResult(error = "Minimal belanja ${rp(p.minBuy)}.")
        val raw = if (p.type == "percent") subtotal * p.value / 100 else p.value
        val capped = if (p.type == "percent" && p.maxDisc > 0) minOf(raw, p.maxDisc) else raw
        return PromoResult(minOf(capped, subtotal))
    }

    suspend fun promos(): List<Promo> =
        db.collection("promos").get().await().documents.map { promoOf(it) }.sortedBy { it.code }

    suspend fun savePromo(p: Promo) {
        db.collection("promos").document(p.code).set(mapOf("type" to p.type, "value" to p.value, "minBuy" to p.minBuy,
            "maxDisc" to p.maxDisc, "startAt" to p.startAt, "endAt" to p.endAt, "active" to p.active)).await()
    }

    suspend fun deletePromo(code: String) { db.collection("promos").document(code).delete().await() }

    suspend fun getPhoto(id: Int): String? =
        db.collection("product_photos").document(id.toString()).get().await().getString("img")

    suspend fun savePhoto(id: Int, b64: String) {
        db.collection("product_photos").document(id.toString()).set(mapOf("img" to b64)).await()
    }

    suspend fun deletePhoto(id: Int) { db.collection("product_photos").document(id.toString()).delete().await() }
}
