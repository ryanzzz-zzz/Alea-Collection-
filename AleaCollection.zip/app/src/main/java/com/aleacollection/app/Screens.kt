package com.aleacollection.app

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun openWa(ctx: android.content.Context, msg: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${waDigits(Live.settings.wa).ifBlank { Config.WA }}?text=" + Uri.encode(msg))))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Terjadi kesalahan. Silakan coba lagi.", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AleaApp() {
    var tab by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Product?>(null) }
    var page by remember { mutableStateOf("") }
    var payOrder by remember { mutableStateOf<Pair<String, Long>?>(null) }
    val appCtx = LocalContext.current
    LaunchedEffect(Unit) {
        if (Repo.ready(appCtx)) {
            try { Live.states = Repo.productStates() } catch (e: Exception) { }
            try { Live.settings = Repo.getSettings() } catch (e: Exception) { }
        }
    }
    val back = detail != null || page != ""
    BackHandler(back) {
        if (page == "checkout") page = "cart" else if (page == "cart" || page == "admin" || page == "pay") page = "" else detail = null
    }
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("ALEA COLLECTION", color = Gold, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 3.sp) },
                navigationIcon = {
                    if (back) IconButton(onClick = {
                        if (page == "checkout") page = "cart" else if (page == "cart" || page == "admin" || page == "pay") page = "" else detail = null
                    }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") }
                },
                actions = {
                    IconButton(onClick = { page = "cart" }) {
                        BadgedBox(badge = { if (Store.cart.isNotEmpty()) Badge { Text("${Store.cart.size}") } }) {
                            Icon(Icons.Default.ShoppingCart, "Keranjang")
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            if (!back) NavigationBar {
                val items = listOf("Home" to Icons.Default.Home, "Katalog" to Icons.Default.Search,
                    "Favorit" to Icons.Default.Favorite, "Pesanan" to Icons.Default.Menu, "Profil" to Icons.Default.Person)
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, label) }, label = { Text(label, fontSize = 11.sp) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val d = detail
            when {
                page == "admin" -> AdminScreen()
                page == "pay" -> PayScreen(payOrder?.first ?: "", payOrder?.second ?: 0L)
                page == "cart" -> CartScreen(shop = { page = ""; detail = null; tab = 1 }, next = { page = "checkout" })
                page == "checkout" -> Checkout(goLogin = { page = ""; tab = 4 }, done = { no, t ->
                    detail = null; tab = 3
                    if (no != null) { payOrder = no to t.toLong(); page = "pay" } else page = ""
                })
                d != null -> Detail(d, goCart = { page = "cart" }, goCheckout = { page = "checkout" })
                tab == 0 -> Home(goShop = { tab = 1 }, open = { detail = it })
                tab == 1 -> CatalogScreen { detail = it }
                tab == 2 -> ProductGrid(Store.favs.map { Catalog.byId(it) }, "Belum ada favorit.") { detail = it }
                tab == 3 -> Pesanan(onPay = { no, t -> payOrder = no to t; page = "pay" })
                else -> Profil(openAdmin = { page = "admin" })
            }
        }
    }
}

@Composable
fun ProductCard(p: Product, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column {
            Box(Modifier.fillMaxWidth().height(100.dp).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center) {
                Text("ALEA", color = Gold, letterSpacing = 4.sp, fontWeight = FontWeight.Light)
                IconButton(onClick = { Store.toggleFav(p.id) }, modifier = Modifier.align(Alignment.TopEnd)) {
                    Icon(if (p.id in Store.favs) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorit", tint = Gold)
                }
            }
            Column(Modifier.padding(12.dp)) {
                Text(p.name, fontWeight = FontWeight.SemiBold, maxLines = 2, minLines = 2)
                Text(p.gender.label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                Text("Mulai " + rp(Prices.from(p)), color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun ProductGrid(list: List<Product>, empty: String, open: (Product) -> Unit) {
    if (list.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(empty) }
    else LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(list, key = { it.id }) { p -> ProductCard(p) { open(p) } }
    }
}

@Composable
fun Section(title: String, list: List<Product>, open: (Product) -> Unit) {
    Column {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list) { p -> ProductCard(p, Modifier.width(160.dp)) { open(p) } }
        }
    }
}

@Composable
fun Home(goShop: () -> Unit, open: (Product) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Card(Modifier.padding(16.dp).fillMaxWidth(), shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Charcoal)) {
                Column(Modifier.padding(24.dp)) {
                    Text("Temukan Aroma Favoritmu", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Parfum berkualitas dengan pilihan ukuran dan kualitas sesuai kebutuhanmu.", color = Ivory)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = goShop, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Charcoal)) {
                        Text("Belanja Sekarang")
                    }
                }
            }
        }
        item { Section("Koleksi Terbaru", Catalog.shown().takeLast(10).reversed(), open) }
        item { Section("Pilihan Untuk Wanita", Catalog.shown().filter { it.gender == Gender.Wanita }.take(10), open) }
        item { Section("Pilihan Untuk Pria", Catalog.shown().filter { it.gender == Gender.Pria }.take(10), open) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun CatalogScreen(open: (Product) -> Unit) {
    var q by remember { mutableStateOf("") }
    var g by remember { mutableStateOf<Gender?>(null) }
    var sort by remember { mutableIntStateOf(0) }
    val base = Catalog.shown().filter { (g == null || it.gender == g) && it.name.contains(q, true) }
    val list = when (sort) {
        1 -> base.sortedBy { Prices.from(it) }
        2 -> base.sortedByDescending { Prices.from(it) }
        else -> base.sortedBy { it.name }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp, 4.dp), singleLine = true,
            placeholder = { Text("Cari parfum...") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(24.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(g == null, { g = null }, { Text("Semua") })
            Gender.values().forEach { x -> FilterChip(g == x, { g = x }, { Text(x.label) }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(16.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Nama A-Z", "Harga termurah", "Harga termahal").forEachIndexed { i, s ->
                FilterChip(sort == i, { sort = i }, { Text(s) })
            }
        }
        ProductGrid(list, "Belum ada produk.", open)
    }
}

@Composable
fun Detail(p: Product, goCart: () -> Unit, goCheckout: () -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf(Quality.Gold) }
    var ml by remember { mutableIntStateOf(30) }
    var n by remember { mutableIntStateOf(1) }
    val sizes = Prices.sizes(p, q)
    val sel = if (ml in sizes) ml else sizes.first()
    val price = Prices.price(p, q, sel)
    val soldOut = Live.stock(p.id) == 0
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.fillMaxWidth().height(200.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center) { Text("ALEA", color = Gold, fontSize = 28.sp, letterSpacing = 8.sp, fontWeight = FontWeight.Light) }
        Text(p.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Kategori: " + p.gender.label, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        Text("Kualitas", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quality.values().forEach { x -> FilterChip(q == x, { q = x }, { Text(x.label) }) }
        }
        Text("Ukuran", fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            sizes.forEach { s -> FilterChip(sel == s, { ml = s }, { Text("$s ML") }) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(rp(price * n), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Gold, modifier = Modifier.weight(1f))
            IconButton({ if (n > 1) n-- }) { Text("−", fontSize = 22.sp) }
            Text("$n", fontSize = 18.sp)
            IconButton({ n++ }) { Icon(Icons.Default.Add, "Tambah") }
        }
        Button(onClick = { Store.add(p.id, q, sel, n); Toast.makeText(ctx, "Ditambahkan ke keranjang", Toast.LENGTH_SHORT).show() },
            Modifier.fillMaxWidth().height(52.dp), enabled = !soldOut) { Text(if (soldOut) "Stok Habis" else "Tambah ke Keranjang") }
        OutlinedButton(onClick = { Store.add(p.id, q, sel, n); goCheckout() }, Modifier.fillMaxWidth().height(52.dp), enabled = !soldOut) { Text("Beli Sekarang") }
        TextButton(onClick = {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "${p.name} • ${q.label} $sel ML • ${rp(price)}\nAlea Collection")
            }
            ctx.startActivity(Intent.createChooser(i, "Bagikan"))
        }) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("Share") }
    }
}

@Composable
fun CartScreen(shop: () -> Unit, next: () -> Unit) {
    if (Store.cart.isEmpty()) {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Keranjangmu masih kosong.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = shop) { Text("Mulai Belanja") }
        }
    } else Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(Store.cart.toList()) { c ->
                val p = Catalog.byId(c.pid)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.SemiBold)
                            Text("${c.q.label} • ${c.ml} ML", fontSize = 13.sp)
                            Text("${rp(Store.unit(c))} × ${c.qty} = ${rp(Store.unit(c) * c.qty)}", color = Gold, fontSize = 13.sp)
                        }
                        IconButton({ Store.change(c, -1) }) { Text("−", fontSize = 20.sp) }
                        Text("${c.qty}")
                        IconButton({ Store.change(c, 1) }) { Icon(Icons.Default.Add, "Tambah") }
                        IconButton({ Store.cart.remove(c) }) { Icon(Icons.Default.Delete, "Hapus") }
                    }
                }
            }
        }
        Column(Modifier.padding(16.dp)) {
            Row { Text("Subtotal", Modifier.weight(1f)); Text(rp(Store.total()), fontWeight = FontWeight.Bold) }
            Text("Ongkir dihitung admin via WhatsApp", fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = next, Modifier.fillMaxWidth().height(52.dp)) { Text("Lanjut Checkout") }
        }
    }
}

@Composable
fun Info(title: String, sub: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(sub, fontSize = 13.sp)
    }
}

