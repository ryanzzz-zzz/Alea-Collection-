package com.aleacollection.app

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun SettingsAdmin() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var s by remember { mutableStateOf(Live.settings) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { try { s = Repo.getSettings() } catch (e: Exception) { } }
    val m = Modifier.fillMaxWidth()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(s.name, { s = s.copy(name = it) }, m, label = { Text("Nama toko") }, singleLine = true)
        OutlinedTextField(s.wa, { s = s.copy(wa = it) }, m, label = { Text("Nomor WhatsApp (08xx atau 62xx)") }, singleLine = true)
        OutlinedTextField(s.address, { s = s.copy(address = it) }, m, label = { Text("Alamat toko") })
        OutlinedTextField(s.email, { s = s.copy(email = it) }, m, label = { Text("Email") }, singleLine = true)
        OutlinedTextField(s.hours, { s = s.copy(hours = it) }, m, label = { Text("Jam operasional") }, singleLine = true)
        OutlinedTextField(s.instagram, { s = s.copy(instagram = it) }, m, label = { Text("Instagram") }, singleLine = true)
        OutlinedTextField(s.tiktok, { s = s.copy(tiktok = it) }, m, label = { Text("TikTok") }, singleLine = true)
        Button(onClick = {
            busy = true
            scope.launch {
                try {
                    Repo.saveSettings(s)
                    Live.settings = s.copy(wa = waDigits(s.wa))
                    Toast.makeText(ctx, "Pengaturan disimpan.", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) { Toast.makeText(ctx, errMsg(e), Toast.LENGTH_LONG).show() }
                busy = false
            }
        }, m.height(52.dp), enabled = !busy) { Text("Simpan Pengaturan") }
    }
}
