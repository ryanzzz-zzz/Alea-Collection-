package com.aleacollection.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFB8962E)
val Ivory = Color(0xFFF8F4EC)
val Charcoal = Color(0xFF1C1C1E)
val Cream = Color(0xFFEFE6D6)

@Composable
fun AleaTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val cs = if (dark) darkColorScheme(
        primary = Gold, onPrimary = Charcoal, background = Charcoal, onBackground = Ivory,
        surface = Color(0xFF2A2A2D), onSurface = Ivory, surfaceVariant = Color(0xFF353538)
    ) else lightColorScheme(
        primary = Charcoal, onPrimary = Ivory, background = Ivory, onBackground = Charcoal,
        surface = Color.White, onSurface = Charcoal, surfaceVariant = Cream
    )
    MaterialTheme(colorScheme = cs, content = content)
}
